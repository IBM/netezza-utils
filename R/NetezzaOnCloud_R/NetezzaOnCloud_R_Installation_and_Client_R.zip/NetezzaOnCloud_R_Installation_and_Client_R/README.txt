This script is recommended for below:

R version : 3.5.1
Kit version: 11.0.0.0
INZA version: 11.0.0