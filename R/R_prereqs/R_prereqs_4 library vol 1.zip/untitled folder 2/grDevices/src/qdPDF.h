#include <R.h>
#include <R_ext/QuartzDevice.h>

QuartzDesc_t QuartzPDF_DeviceCreate(void *dd, QuartzFunctions_t *fn, QuartzParameters_t *par);

