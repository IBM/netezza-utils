"islands" <-
structure(c(11506, 5500, 16988, 2968, 16, 184, 23, 280, 84, 73, 25, 43, 21,
82, 3745, 840, 13, 30, 30, 89, 40, 33, 49, 14, 42, 227, 16, 36, 29, 15, 306,
44, 58, 43, 9390, 32, 13, 29, 6795, 16, 15, 183, 14, 26, 19, 13, 12, 82),
.Names = c("Africa", "Antarctica", "Asia", "Australia", "Axel Heiberg", 
"Baffin", "Banks", "Borneo", "Britain", "Celebes", "Celon", "Cuba", "Devon", 
"Ellesmere", "Europe", "Greenland", "Hainan", "Hispaniola", "Hokkaido", 
"Honshu", "Iceland", "Ireland", "Java", "Kyushu", "Luzon", "Madagascar", 
"Melville", "Mindanao", "Moluccas", "New Britain", "New Guinea",
"New Zealand (N)", "New Zealand (S)", "Newfoundland", "North America",
"Novaya Zemlya", "Prince of Wales", "Sakhalin", "South America",
"Southampton", "Spitsbergen", "Sumatra", "Taiwan", "Tasmania",
"Tierra del Fuego", "Timor", "Vancouver", "Victoria"))
